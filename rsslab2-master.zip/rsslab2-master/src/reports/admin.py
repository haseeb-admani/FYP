from django.contrib import admin

from .models import PatientNotes


admin.site.register(PatientNotes)
